if (Meteor.isClient) {
   var img_data = [
   {
      img_src:"The Great Gatsby by F. Scott Fitzgerald.png",
      img_alt:"The Great Gatsby by F. Scott Fitzgerald" 
   }, 
   {
      img_src:"To Kill a Mockingbird.png",
      img_alt:"To Kill a Mockingbird" 
   }, 
   {
      img_src:"Pride and Prejudice, by Jane Austen.png",
      img_alt:"Pride and Prejudice, by Jane Austen" 
   }, 

   ];

   Template.images.helpers({images:img_data});


   Template.images.events({
    'click .js-images':function(event){
        $(event.target).css("width", "50px");
    }
   });

}

if (Meteor.isServer) {
   console.log("I am the server");
}


console.log("where am I running");

